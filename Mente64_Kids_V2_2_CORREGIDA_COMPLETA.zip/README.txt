MENTE64 KIDS V2.2
=================

Correcciones incluidas:
- 10 videos completos recuperados y duraciones reales corregidas.
- La pantalla de clase muestra la duración real leída por el reproductor.
- Piezas blancas/negras más diferenciables en el tablero.
- Coronación de peón con selector: dama, torre, alfil o caballo.
- Perfil editable: selector de avatar del alumno.
- Configuración EAS conserva el projectId del proyecto.
